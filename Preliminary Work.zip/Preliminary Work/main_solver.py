import pandas as pd
from pulp import *
import numpy as np
import matplotlib.pyplot as plt
A=[{'RM': 0.14444444444444446, 'LSTAT': 0.13333333333333336, 'INDUS': 0.12222222222222222,
    'NOX': 0.11111111111111109, 'CRIM': 0.09999999999999999, 'AGE': 0.08888888888888889,
    'DIS': 0.07777777777777778, 'TAX': 0.06666666666666668, 'PIRATIO': 0.055555555555555546,
    'ZN': 0.044444444444444446, 'RAD': 0.033333333333333326, 'CHAS': 0.022222222222222223, 'B': 0.0},
]

# 读取数据
X_test = pd.read_csv('/Users/liuzihao/Desktop/公平框架New/Boston_X_scaled.csv')
y_pred = pd.read_csv('/Users/liuzihao/Desktop/公平框架New/predicted_values.csv')
y_test = pd.read_csv('/Users/liuzihao/Desktop/公平框架New/Y_boston.csv')

# 设置ϵ的起始值和终止值以及步长
epsilon_values = np.arange(0.1, 1.1, 0.1)
delta_values = []

# 假设我们使用的是 加权的ℓ2 范数
def lp_norm(x_prime, x_double_prime, p=2):
    # 求解 ℓp 范数，这里我们使用 ℓ2 范数
    return sum(dict_weights[key]*(x_prime[key] - x_double_prime[key])**p for key in dict_weights)**(1/p)
# 定义问题
for epsilon in epsilon_values:
    prob = LpProblem("Maximize_delta", LpMaximize)

    # 加载权重字典，它是一个包含特征权重的字典
    # 比如：dict_weights = {'feature1': 1, 'feature2': 2, ...}
    dict_weights = A[0]  # 替换为实际的权重字典

    # 定义变量
    # 我们将使用X_test中的所有行作为潜在的x'和x''，因此我们需要为每一行创建一个变量
    variables_x_prime = LpVariable.dicts("x_prime", range(len(X_test)), 0, len(X_test)-1, cat='Integer')
    variables_x_double_prime = LpVariable.dicts("x_double_prime", range(len(X_test)), 0, len(X_test)-1, cat='Integer')

    # 定义目标函数-这里我们需要计算每一对 (x', x'') 的delta，并选择最大值
    # 我们将使用一个辅助变量来确保目标函数遵从线性规划的规则
    delta = LpVariable("delta", lowBound=0)

    prob += -delta  # 我们的目标是最小化delta

    # 对于X_test中的每一对可能的行索引(i, j)，添加约束
    for i in range(len(X_test)):
        for j in range(i+1, len(X_test)):  # 避免重复对和自己比较
            x_prime_row = X_test.iloc[i]
            x_double_prime_row = X_test.iloc[j]
            
            # 计算两个输入之间的dfair值
            dfair_val = lp_norm(x_prime_row, x_double_prime_row)
            # 如果dfair_val小于或等于ϵ，则考虑它们之间的预测值差
            if dfair_val <= epsilon:
                y_pred_val_i = y_pred.iloc[i].values[0]  # 假设y_pred.csv中只有一列
                y_pred_val_j = y_pred.iloc[j].values[0]  # 假设y_pred.csv中只有一列
                
                # 计算预测值的差值的绝对值
                delta_val = abs(y_pred_val_i - y_pred_val_j)
                
                # 添加约束以确保 delta 总是大于或等于任何符合条件的预测值差
                prob += delta >= delta_val

    # 求解问题
    prob.solve()
     # 收集求解结果
    optimal_delta = value(delta)
    delta_values.append(optimal_delta)
    print(f"Epsilon: {epsilon}, Optimal delta: {optimal_delta}")

# 绘制散点图
plt.scatter(epsilon_values, delta_values)
plt.title("Scatter plot of Epsilon vs. Optimal Delta")
plt.xlabel("Epsilon")
plt.ylabel("Optimal Delta")
plt.grid(True)
plt.show()
