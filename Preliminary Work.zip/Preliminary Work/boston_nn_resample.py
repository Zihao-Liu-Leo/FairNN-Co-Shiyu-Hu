import pandas as pd
from sklearn.neural_network import MLPRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import StandardScaler
import numpy as np

# 加载Boston房价数据集
data = pd.read_csv('boston.csv')  # 替换为你的Boston数据集路径

# 特征列表 - 请确保这些特征与boston.csv中的列名相匹配
features = ['CRIM', 'ZN', 'INDUS', 'CHAS', 'NOX', 'RM', 'AGE', 'DIS', 'RAD', 'TAX', 'PIRATIO', 'B', 'LSTAT']

# 目标变量 - 请确保这个目标变量与boston.csv中的列名相匹配
target = 'MEDV'

# 选择特征和目标变量
X = data[features]
y = data[target]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 42)

def resample(X_train, y_train, c1=1, c2=1):
    B = X_train['B']
    B_std = (B - np.mean(B)) / np.std(B)
    B_w = np.abs(B_std) + c1
    M = y_train
    M_std = (M - np.mean(M)) / np.std(M)
    M_m = np.sum(B_w * M_std) / np.sum(B_w)
    W = B_w / (np.abs(M_std - M_m) + c2)
    W = W / np.sum(W)
    return W

np.random.seed(42)
choices = np.random.choice(a = X_train.index, size = len(X_train), replace = True, p = resample(X_train, y_train, 1, 1))
choices = sorted(list(choices))
X_train = X_train.loc[choices].reset_index(drop = True)
y_train = y_train.loc[choices].reset_index(drop = True)
X_resample = pd.concat([X_train, X_test])

# 数据标准化
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_resample)

# 将经过标准化的数据转换为DataFrame
X_scaled_df = pd.DataFrame(X_scaled, columns = features)

# 将标准化后的数据保存为CSV文件
X_scaled_df.to_csv('X_scaled.csv', index = False)

train_len = len(X_train)
test_len = len(X_test)

X_train = X_scaled[:train_len, :]
X_test = X_scaled[train_len:, :]

# 创建一个多层感知机模型
# 这里可以调整hidden_layer_sizes和其他参数来优化网络
mlp = MLPRegressor(hidden_layer_sizes=(100, 50), max_iter=1000, activation='relu', solver='adam', random_state=42)

# 训练模型
mlp.fit(X_train, y_train)

# 预测测试集
y_pred = mlp.predict(X_test)

# 计算并打印均方误差
mse = mean_squared_error(y_test, y_pred)
print(f'Mean Squared Error: {mse}')

# 将测试特征、真实目标值和预测目标值转换为DataFrame
X_test_df = pd.DataFrame(X_test, columns=features)
y_test_df = pd.DataFrame(y_test, columns=[target])
y_pred_df = pd.DataFrame(y_pred, columns=['Predicted_' + target])

# 将测试特征DataFrame和真实目标值、预测目标值的DataFrame进行横向合并
results_df = pd.concat([X_test_df, y_test_df, y_pred_df], axis=1)

# 输出DataFrame到CSV文件
results_df.to_csv('test_predictions.csv', index=False)

# 如果你还想分别输出X_test, y_test, 和 y_pred，你可以使用以下命令
X_test_df.to_csv('X_test.csv', index=False)
y_test_df.to_csv('y_test.csv', index=False)
y_pred_df.to_csv('y_pred.csv', index=False)
