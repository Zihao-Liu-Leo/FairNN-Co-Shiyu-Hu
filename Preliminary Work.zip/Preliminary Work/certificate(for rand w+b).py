#main:task1:大型验证函数
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
# 加载Boston-scaled数据集
data = pd.read_csv('/Users/liuzihao/Desktop/公平框架New/Boston_X_scaled.csv')

# 假设目标值存储在"Boston-target.csv"文件中
# 请替换为实际的目标值文件路径
target = pd.read_csv('/Users/liuzihao/Desktop/公平框架New/Y_boston.csv')
# 将特征和目标分离
X = data.values
y = target.values.flatten()
# 初始化权重和偏置
# 这里假设权重w和偏置b是已知的，且与特征数量匹配
# 请替换为实际的权重和偏置值
input_size = X.shape[1]
w = np.random.randn(input_size)  # 随机初始化权重
b = np.random.randn()            # 随机初始化偏置

# Sigmoid函数
def sigmoid(z):
    return 1 / (1 + np.exp(-z))

# Sigmoid函数的导数
def sigmoid_derivative(z):
    return sigmoid(z) * (1 - sigmoid(z))

# 分段数
M = 16
# 预设分段区间
z_segments = np.linspace(-5, 5, M + 1)
# sigmoid函数在分段点上的值
sigmoid_values = sigmoid(z_segments)
# sigmoid函数导数在分段中点上的值
midpoints = (z_segments[:-1] + z_segments[1:]) / 2
derivative_values = sigmoid_derivative(midpoints)

# 计算Upper bounds
upper_slopes = (sigmoid_values[1:] - sigmoid_values[:-1]) / (z_segments[1:] - z_segments[:-1])
upper_intercepts = sigmoid_values[:-1] - upper_slopes * z_segments[:-1]

# 计算Lower bounds
lower_slopes = derivative_values
lower_intercepts = sigmoid_values[:-1] - lower_slopes * z_segments[:-1]

# 定义Upper bound函数（向量化）
def upper_sigmoid(z):
    z = np.asarray(z)  # 确保z是一个numpy数组
    y_upper = np.zeros_like(z)
    for i in range(M):
        mask = (z >= z_segments[i]) & (z < z_segments[i+1])
        y_upper[mask] = upper_slopes[i] * z[mask] + upper_intercepts[i]
    y_upper[z >= 5] = sigmoid(5)
    y_upper[z < -5] = sigmoid(-5)
    return y_upper

# 定义Lower bound函数（向量化）
def lower_sigmoid(z):
    z = np.asarray(z)  # 确保z是一个numpy数组
    y_lower = np.zeros_like(z)
    for i in range(M):
        mask = (z >= z_segments[i]) & (z < z_segments[i+1])
        y_lower[mask] = lower_slopes[i] * z[mask] + lower_intercepts[i]
    y_lower[z >= 5] = sigmoid(5)
    y_lower[z < -5] = sigmoid(-5)
    return y_lower

# 测试函数
#z_test = 0.1
#print(f"Upper bound of sigmoid({z_test}) is {upper_sigmoid(z_test)}")
#print(f"Lower bound of sigmoid({z_test}) is {lower_sigmoid(z_test)}")

# 单层全连接神经网络的前向传播(upper)
def forward_pass_upper(X, w, b):
    z = np.dot(X, w) + b
    y_pred_upper = 5+45*upper_sigmoid(z)
    return y_pred_upper

# 单层全连接神经网络的前向传播(lower)
def forward_pass_lower(X, w, b):
    z = np.dot(X, w) + b
    y_pred_lower = 5+45*lower_sigmoid(z)
    return y_pred_lower

# 使用神经网络计算输出值y
y_pred_upper = forward_pass_upper(X, w, b)
y_pred_lower = forward_pass_lower(X, w, b)



import pandas as pd
from pulp import *
import numpy as np
import matplotlib.pyplot as plt

A=[{'RM': 0.14444444444444446, 'LSTAT': 0.13333333333333336, 'INDUS': 0.12222222222222222,
    'NOX': 0.11111111111111109, 'CRIM': 0.09999999999999999, 'AGE': 0.08888888888888889,
    'DIS': 0.07777777777777778, 'TAX': 0.06666666666666668, 'PIRATIO': 0.055555555555555546,
    'ZN': 0.044444444444444446, 'RAD': 0.033333333333333326, 'CHAS': 0.022222222222222223, 'B': 0.0},
]

X_test = pd.read_csv('/Users/liuzihao/Desktop/公平框架New/Boston_X_scaled.csv')
y_test = pd.read_csv('/Users/liuzihao/Desktop/公平框架New/Y_boston.csv')

# 设置ϵ的起始值和终止值以及步长
epsilon_values = np.arange(0.1, 0.5, 0.01)
#epsilon_values = [0.3]
delta_values = []

# 我们使用的是加权的ℓ2 范数
def lp_norm(x_prime, x_double_prime, p=2):
    # 求解 ℓp 范数，这里我们使用 ℓ2 范数
    return sum(dict_weights[key]*(x_prime[key] - x_double_prime[key])**p for key in dict_weights)**(1/p)

# 定义问题
for epsilon in epsilon_values:
    prob = LpProblem("Maximize_delta", LpMaximize)

    # 加载权重字典，它是一个包含特征权重的字典
    dict_weights = A[0]  # 替换为实际的权重字典
# 定义变量
    # 我们将使用X_test中的所有行作为潜在的x'和x''，因此我们需要为每一行创建一个变量
    variables_x_prime = LpVariable.dicts("x_prime", range(len(X_test)), 0, len(X_test)-1, cat='Integer')
    variables_x_double_prime = LpVariable.dicts("x_double_prime", range(len(X_test)), 0, len(X_test)-1, cat='Integer')
    
    # 定义目标函数-这里我们需要计算每一对 (x', x'') 的delta，并选择最大值
    # 我们将使用一个辅助变量来确保目标函数遵从线性规划的规则
    delta = LpVariable("delta", lowBound=0)

    prob += -delta  # 我们的目标是最小化delta(因为得到的都是delta>=几的constraint)
    # 对于X_test中的每一对可能的行索引(i, j)，添加约束
    for i in range(len(X_test)):
        for j in range(i+1, len(X_test)):  # 避免重复对和自己比较
            x_prime_row = X_test.iloc[i]
            x_double_prime_row = X_test.iloc[j]
            
            # 计算两个输入之间的dfair值
            dfair_val = lp_norm(x_prime_row, x_double_prime_row)
            # 如果dfair_val小于或等于ϵ，则考虑它们之间的预测值差
            if dfair_val <= epsilon:               
                # 计算预测值的差值的绝对值
                delta_val = max(abs(y_pred_upper[i] - y_pred_lower[j]),
                                abs(y_pred_lower[i] - y_pred_upper[j]))
                
                # 添加约束以确保 delta 总是大于或等于任何符合条件的预测值差
                prob += delta >= delta_val
           # 求解问题
    prob.solve()
     # 收集求解结果
    optimal_delta = value(delta)
    delta_values.append(optimal_delta)
    print(f"Epsilon: {epsilon}, Optimal delta: {optimal_delta}")

# 绘制散点图
plt.scatter(epsilon_values, delta_values)
plt.title("Scatter plot of Epsilon vs. Optimal Delta")
plt.xlabel("Epsilon")
plt.ylabel("Optimal Delta")
plt.grid(True)
plt.show() 
    


#0.3的结果（执行20次）
Task=[16.277752,31.012339,39.094612,17.324209,23.933097,30.815244,34.569671,22.839798,19.51938,31.990121,
      20.941301,11.379573,32.718124,31.642898,17.38612,40.029755,35.716721,38.800552,26.110161,25.486822]
# 计算平均值
average_value = np.mean(Task)
print(f"Average value: {average_value:.2f}")  # 保留两位小数

#Average value: 27.38

# 从大到小排序
Task_sorted = sorted(Task, reverse=True)

# 绘制折线图
plt.plot(Task_sorted, marker='o')
plt.title('Task Values Sorted from Highest to Lowest')
plt.xlabel('Index')
plt.ylabel('Value')
plt.grid(True)
plt.show()
