import numpy as np
import pandas as pd
from scipy.optimize import minimize
from pulp import *

# 加载数据集
data = pd.read_csv('/Users/liuzihao/Desktop/公平框架New/Boston_X_scaled.csv')
target = pd.read_csv('/Users/liuzihao/Desktop/公平框架New/Y_boston.csv')
X = data.values
y = target.values.flatten()

# 初始化权重和偏置
input_size = X.shape[1]
w = np.random.randn(input_size)  # 随机初始化权重
b = np.random.randn()            # 随机初始化偏置

# Sigmoid函数及其导数
def sigmoid(z):
    return 1 / (1 + np.exp(-z))

# 分段数
M = 16
# 预设分段区间
z_segments = np.linspace(-5, 5, M + 1)
# sigmoid函数导数在分段中点上的值
midpoints = (z_segments[:-1] + z_segments[1:]) / 2
derivative_values = sigmoid(midpoints) * (1 - sigmoid(midpoints))

# 计算Lower bounds的斜率
lower_slopes = derivative_values

# 定义Lower bound函数（向量化）
def lower_sigmoid(z):
    z = np.asarray(z)  # 确保z是一个numpy数组
    y_lower = np.zeros_like(z)
    for i in range(M):
        mask = (z >= z_segments[i]) & (z < z_segments[i+1])
        y_lower[mask] = lower_slopes[i] * (z[mask] - z_segments[i])
    y_lower[z >= z_segments[-1]] = 1  # 最后一个分段上限为1
    y_lower[z < z_segments[0]] = 0    # 第一个分段下限为0
    return y_lower

# 单层全连接神经网络的前向传播(lower)
def forward_pass_lower(X, w, b):
    z = np.dot(X, w) + b
    y_pred_lower = 5+45*lower_sigmoid(z)
    return y_pred_lower




A=[{'RM': 0.14444444444444446, 'LSTAT': 0.13333333333333336, 'INDUS': 0.12222222222222222,
    'NOX': 0.11111111111111109, 'CRIM': 0.09999999999999999, 'AGE': 0.08888888888888889,
    'DIS': 0.07777777777777778, 'TAX': 0.06666666666666668, 'PIRATIO': 0.055555555555555546,
    'ZN': 0.044444444444444446, 'RAD': 0.033333333333333326, 'CHAS': 0.022222222222222223, 'B': 0.0},
]

X_test = pd.read_csv('/Users/liuzihao/Desktop/公平框架New/Boston_X_scaled.csv')

epsilon=0.3

delta_values = []

dict_weights = A[0] 

def lp_norm(x_prime, x_double_prime, p=2):
    # 求解 ℓp 范数，这里我们使用 ℓ2 范数
    return sum(dict_weights[key]*(x_prime[key] - x_double_prime[key])**p for key in dict_weights)**(1/p)

def compute_delta(w, b, epsilon):
    y_pred_lower = forward_pass_lower(X, w, b)
    prob = LpProblem("Maximize_delta", LpMaximize)
    dict_weights = A[0]  # 替换为实际的权重字典
    variables_x_prime = LpVariable.dicts("x_prime", range(len(X_test)), 0, len(X_test)-1, cat='Integer')
    variables_x_double_prime = LpVariable.dicts("x_double_prime", range(len(X_test)), 0, len(X_test)-1, cat='Integer')
    delta = LpVariable("delta", lowBound=0)
    prob += -delta  # 我们的目标是最小化delta(因为得到的都是delta>=几的constraint) 
    for i in range(len(X_test)):
            for j in range(i+1, len(X_test)):  # 避免重复对和自己比较
                x_prime_row = X_test.iloc[i]
                x_double_prime_row = X_test.iloc[j]               
                # 计算两个输入之间的dfair值
                dfair_val = lp_norm(x_prime_row, x_double_prime_row)
                # 如果dfair_val小于或等于ϵ，则考虑它们之间的预测值差
                if dfair_val <= epsilon:               
                    # 计算预测值的差值的绝对值
                    delta_val = abs(y_pred_lower[i] - y_pred_lower[j])            
                    # 添加约束以确保 delta 总是大于或等于任何符合条件的预测值差
                    prob += delta >= delta_val
               # 求解问题
    prob.solve(PULP_CBC_CMD(msg=False))
    optimal_delta = value(delta)
    delta_values.append(optimal_delta)
    print(f"Epsilon: {epsilon}, Optimal delta: {optimal_delta}")
    return(optimal_delta)


def estimate_gradient(w, b, epsilon, optimal_delta, h=1e-4):
    grad_w = np.zeros_like(w)
    grad_b = 0

    # 计算w的梯度
    for i in range(len(w)):
        w_plus = np.copy(w)
        w_plus[i] += h
        delta_plus = compute_delta(w_plus, b, epsilon)
        
        w_minus = np.copy(w)
        w_minus[i] -= h
        delta_minus = compute_delta(w_minus, b, epsilon)

        grad_w[i] = (delta_plus - delta_minus) / (2 * h)
    # 计算w的梯度    
    b_plus = b + h
    delta_plus = compute_delta(w, b_plus, epsilon)

    b_minus = b - h
    delta_minus = compute_delta(w, b_minus, epsilon)

    grad_b = (delta_plus - delta_minus) / (2 * h)

    return grad_w, grad_b

# 使用梯度下降更新权重和偏置
def gradient_descent(w, b, epochs, learning_rate, epsilon):
    for epoch in range(epochs):
        optimal_delta=compute_delta(w, b, epsilon)
        grad_w, grad_b=estimate_gradient(w, b, epsilon, optimal_delta, h=1e-4)
        w -= learning_rate * grad_w
        b -= learning_rate * grad_b
        print(f"Epoch {epoch}, delta: {optimal_delta}")
    return w, b

# 设置参数
learning_rate = 0.01
epochs = 10  # 使用较少的迭代次数来加快演示速度
epsilon = 0.3

# 运行梯度下降
w, b = gradient_descent(w, b, epochs, learning_rate, epsilon)
