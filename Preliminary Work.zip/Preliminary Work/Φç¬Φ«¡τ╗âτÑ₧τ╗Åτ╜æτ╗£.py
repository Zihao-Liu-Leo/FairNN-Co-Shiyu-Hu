import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

# 加载Boston-scaled数据集
data = pd.read_csv('/Users/liuzihao/Desktop/公平框架New/Boston_X_scaled.csv')

# 假设目标值存储在"Boston-target.csv"文件中
# 请替换为实际的目标值文件路径
target = pd.read_csv('/Users/liuzihao/Desktop/公平框架New/Y_boston.csv')
# 将特征和目标分离
X = data.values
y = target.values.flatten()

# 初始化权重和偏置
# 这里假设权重w和偏置b是已知的，且与特征数量匹配
# 请替换为实际的权重和偏置值
input_size = X.shape[1]
w = np.random.randn(input_size)  # 随机初始化权重
b = np.random.randn()            # 随机初始化偏置

# Sigmoid激活函数
def sigmoid(x):
    return 1 / (1 + np.exp(-x))

# 单层全连接神经网络的前向传播
def forward_pass(X, w, b):
    z = np.dot(X, w) + b
    y_pred = 5+45*sigmoid(z)
    return y_pred

# 使用神经网络计算输出值y
y_pred = forward_pass(X, w, b)

# 打印输出值y
print("Predicted Y values are: \n", y_pred)

import pandas as pd


# 将y_pred数组转换为pandas DataFrame
y_pred_df = pd.DataFrame(y_pred, columns=['Predicted Values'])

# 输出DataFrame到CSV文件
y_pred_df.to_csv('predicted_values.csv', index=False)

print("Predicted Y values have been saved to 'predicted_values.csv'")